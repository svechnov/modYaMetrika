﻿--------------------
modYaMetrika
--------------------
Author: Evgeniy Savitskiy <sei.olympus@gmail.com>
--------------------

Yandex.Metrika for MODx Revolution.