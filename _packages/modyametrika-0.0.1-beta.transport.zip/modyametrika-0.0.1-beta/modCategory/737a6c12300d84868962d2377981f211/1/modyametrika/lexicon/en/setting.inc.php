<?php 

$_lang['area_modyametrika_main'] = 'main'; 

$_lang['setting_modyametrika_token'] = 'The authorization token is'; 
$_lang['setting_modyametrika_token_desc'] = 'To use the module is necessary and sufficient to obtain a debug token for your account <br /> By default the token test user - 05dd3dd84ff948fdae2bc4fb91f13e22 <br /> <a target="_blank" href="https://api.yandex.ru/metrika/doc/ref/concepts/authorization.xml">Information about obtaining authorization token</a> '; 
$_lang['setting_modyametrika_counter'] = 'Number of the counter'; 
$_lang['setting_modyametrika_counter_desc'] = 'ID counter with which work will be done <br /> By default the counter number for a test user - 2138128'; 
$_lang['setting_modyametrika_api_url'] = 'URL to connect to the API Yandex.Metrika'; 
$_lang['setting_modyametrika_api_url_desc'] = ''; 
$_lang['setting_modyametrika_counter_code'] = 'HTML-code counter'; 
$_lang['setting_modyametrika_counter_code_desc'] = 'The code which automatically will be placed on all pages'; 
$_lang['setting_modyametrika_counter_code_show'] = 'Display the counter code on the site'; 
$_lang['setting_modyametrika_counter_code_show_desc'] = ''; 
$_lang['setting_modyametrika_only_static'] = 'Only static information'; 
$_lang['setting_modyametrika_only_static_desc'] = 'If you select <b>Yes</ b>, then the functionality will not be available for viewing information about the counters and statistics';